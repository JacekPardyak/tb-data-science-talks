if(! require('keras')) install.packages('keras')
if(! require('yardstick')) install.packages('yardstick')
library(keras)

library(tensorflow)
tf$constant("Hello World")
