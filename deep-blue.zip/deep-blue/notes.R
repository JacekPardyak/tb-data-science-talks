system('lsb_release -a') 
install.packages("tensorflow")
library(tensorflow)
install_tensorflow()
tf$constant("Hellow Tensorflow")


library(tidyverse) # mainly dplyr
library(udpipe)    # tokenization & lemmatization
library(caret)     # used to split the dataset to train / test
library(keras)     # because Keras :)

# directory for source data files
network_path <- 'http://www.jla-data.net/ENG/2019-01-25-vocabulary-based-text-classification_files/'

tf_tweets <- tempfile(fileext = ".csv") # create a temporary csv file
download.file(paste0(network_path, 'tidy_tweets.csv'), tf_tweets, quiet = T)
tweets <- read.csv(tf_tweets, stringsAsFactors = F) # read the tweet data in

# download current udpipe model for English
udtarget <- udpipe_download_model(language = "english",
                                  model_dir = tempdir())
# load the model
udmodel <- udpipe_load_model(file = udtarget$file_model) 

table(tweets$name) # verify structure of downloaded tweets


install.packages("progressr")
install.packages("curl")
‘curl’, ‘openssl’